-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: sipesa
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sipesa`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sipesa` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sipesa`;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `tipe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_foreign` (`user_id`),
  CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,NULL,'laporan_warga','Laporan QR LP-20260827-0010 untuk tong BT-0501','{\"status_tong\": \"setengah_penuh\", \"trash_bin_id\": 20, \"public_report_id\": 10}','2026-08-27 16:12:36','2026-08-27 16:12:36'),(2,NULL,'laporan_warga','Laporan QR LP-20260827-0010 untuk tong BT-0501','{\"status_tong\": \"penuh\", \"trash_bin_id\": 20, \"public_report_id\": 11}','2026-08-27 16:23:36','2026-08-27 16:23:36'),(3,NULL,'laporan_warga','Laporan QR LP-20260827-0010 untuk tong BT-0501','{\"status_tong\": \"penuh\", \"trash_bin_id\": 20, \"public_report_id\": 12}','2026-08-27 16:47:35','2026-08-27 16:47:35'),(4,NULL,'laporan_warga','Laporan QR LP-20260827-0011 untuk tong BT-0501','{\"status_tong\": \"setengah_penuh\", \"trash_bin_id\": 20, \"public_report_id\": 13}','2026-08-27 17:00:44','2026-08-27 17:00:44'),(5,NULL,'laporan_warga','Laporan QR LP-20260827-0011 untuk tong SD-0103','{\"status_tong\": \"setengah_penuh\", \"trash_bin_id\": 3, \"public_report_id\": 14}','2026-08-27 17:03:26','2026-08-27 17:03:26'),(6,NULL,'laporan_warga','Laporan QR LP-20260827-0012 untuk tong BT-0501','{\"status_tong\": \"penuh\", \"trash_bin_id\": 20, \"public_report_id\": 15}','2026-08-27 19:09:53','2026-08-27 19:09:53'),(7,NULL,'laporan_warga','Laporan QR LP-20260827-0013 untuk tong SD-0103','{\"status_tong\": \"penuh\", \"trash_bin_id\": 3, \"public_report_id\": 16}','2026-08-27 19:57:11','2026-08-27 19:57:11'),(8,1,'laporan_warga','Menanggapi laporan LP-20260827-0013','{\"status\": \"selesai\", \"public_report_id\": 16}','2026-08-27 19:57:41','2026-08-27 19:57:41'),(9,1,'delete','Menghapus pengguna: Siswa Contoh','{\"id\": 8, \"name\": \"Siswa Contoh\", \"email\": \"siswa@sipesa.test\", \"alamat\": null, \"avatar\": null, \"role_id\": 6, \"unit_id\": 1, \"created_at\": \"2026-08-27T07:39:54.000000Z\", \"no_telepon\": \"081200000005\", \"updated_at\": \"2026-08-27T07:39:54.000000Z\", \"email_verified_at\": \"2026-08-27T07:39:54.000000Z\"}','2026-08-27 19:59:07','2026-08-27 19:59:07'),(10,1,'laporan_warga','Menghapus laporan LP-20260827-0012',NULL,'2026-08-27 20:04:05','2026-08-27 20:04:05'),(11,1,'laporan_warga','Menghapus laporan LP-20260827-0011',NULL,'2026-08-27 20:04:07','2026-08-27 20:04:07'),(12,1,'laporan_warga','Menghapus laporan LP-20260827-0010',NULL,'2026-08-27 20:04:10','2026-08-27 20:04:10'),(13,1,'laporan_warga','Menghapus laporan LP-20260827-0004',NULL,'2026-08-27 20:04:15','2026-08-27 20:04:15'),(14,1,'laporan_warga','Menghapus laporan LP-20260827-0002',NULL,'2026-08-27 20:04:17','2026-08-27 20:04:17'),(15,1,'laporan_warga','Menghapus laporan LP-20260827-0001',NULL,'2026-08-27 20:04:20','2026-08-27 20:04:20'),(16,1,'laporan_warga','Menghapus laporan LP-20260827-0003',NULL,'2026-08-27 20:04:22','2026-08-27 20:04:22'),(17,1,'laporan_warga','Menghapus laporan LP-20260827-0005',NULL,'2026-08-27 20:04:24','2026-08-27 20:04:24'),(18,1,'laporan_warga','Menghapus laporan LP-20260827-0006',NULL,'2026-08-27 20:04:25','2026-08-27 20:04:25'),(19,1,'laporan_warga','Menghapus laporan LP-20260827-0007',NULL,'2026-08-27 20:04:27','2026-08-27 20:04:27'),(20,1,'laporan_warga','Menghapus laporan LP-20260827-0008',NULL,'2026-08-27 20:04:31','2026-08-27 20:04:31'),(21,1,'laporan_warga','Menghapus laporan LP-20260827-0009',NULL,'2026-08-27 20:04:33','2026-08-27 20:04:33'),(22,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #1 menjadi sudah_diangkut','[]','2026-08-27 20:11:44','2026-08-27 20:11:44'),(23,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #3 menjadi sudah_diangkut','[]','2026-08-27 20:12:09','2026-08-27 20:12:09'),(24,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #1 menjadi kosong','[]','2026-08-27 20:12:13','2026-08-27 20:12:13'),(25,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #2 menjadi kosong','[]','2026-08-27 20:12:18','2026-08-27 20:12:18'),(26,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #3 menjadi kosong','[]','2026-08-27 20:12:22','2026-08-27 20:12:22'),(27,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #4 menjadi kosong','[]','2026-08-27 20:12:26','2026-08-27 20:12:26'),(28,1,'trash_bin','Memperbarui status tempat sampah Tong BTM Kampus B #5 menjadi kosong','[]','2026-08-27 20:12:31','2026-08-27 20:12:31'),(29,1,'trash_bin','Memperbarui status tempat sampah Tong SD Kampus B #1 menjadi kosong','[]','2026-08-27 20:12:35','2026-08-27 20:12:35'),(30,1,'trash_bin','Memperbarui status tempat sampah Tong SD Kampus B #1 menjadi kosong','[]','2026-08-27 20:12:39','2026-08-27 20:12:39'),(31,1,'trash_bin','Memperbarui status tempat sampah Tong SD Kampus B #2 menjadi kosong','[]','2026-08-27 20:12:42','2026-08-27 20:12:42'),(32,1,'trash_bin','Memperbarui status tempat sampah Tong SD Kampus B #3 menjadi kosong','[]','2026-08-27 20:12:46','2026-08-27 20:12:46'),(33,NULL,'laporan_warga','Laporan QR LP-20260827-0014 untuk tong BT-0501','{\"status_tong\": \"setengah_penuh\", \"trash_bin_id\": 20, \"public_report_id\": 17}','2026-08-27 20:13:29','2026-08-27 20:13:29'),(34,NULL,'laporan_warga','Laporan QR LP-20260827-0015 untuk tong BT-0502','{\"status_tong\": \"setengah_penuh\", \"trash_bin_id\": 21, \"public_report_id\": 18}','2026-08-27 20:14:02','2026-08-27 20:14:02'),(35,NULL,'laporan_warga','Laporan QR LP-20260827-0016 untuk tong BT-0503','{\"status_tong\": \"penuh\", \"trash_bin_id\": 22, \"public_report_id\": 19}','2026-08-27 20:14:08','2026-08-27 20:14:08'),(36,NULL,'laporan_warga','Laporan QR LP-20260827-0017 untuk tong BT-0504','{\"status_tong\": \"penuh\", \"trash_bin_id\": 23, \"public_report_id\": 20}','2026-08-27 20:14:48','2026-08-27 20:14:48'),(37,1,'create','Menambahkan pengguna: qqq','{\"id\": 9, \"name\": \"qqq\", \"email\": \"petugas3@sipesa.test\", \"alamat\": \"dayeuh\\ndayeuh\", \"role_id\": \"1\", \"unit_id\": null, \"created_at\": \"2026-08-27T13:43:56.000000Z\", \"no_telepon\": \"097728\", \"updated_at\": \"2026-08-27T13:43:56.000000Z\"}','2026-08-27 20:43:56','2026-08-27 20:43:56'),(38,1,'delete','Menghapus pengguna: qqq','{\"id\": 9, \"name\": \"qqq\", \"email\": \"petugas3@sipesa.test\", \"alamat\": \"dayeuh\\ndayeuh\", \"avatar\": null, \"role_id\": 1, \"unit_id\": null, \"created_at\": \"2026-08-27T13:43:56.000000Z\", \"no_telepon\": \"097728\", \"updated_at\": \"2026-08-27T13:43:56.000000Z\", \"email_verified_at\": null}','2026-08-27 20:44:05','2026-08-27 20:44:05'),(39,1,'update','Memperbarui pengguna: Petugas 1','{\"alamat\": \"dayeuh\\ndayeuh\", \"unit_id\": \"1\", \"updated_at\": \"2026-08-27 20:44:34\"}','2026-08-27 20:44:34','2026-08-27 20:44:34'),(40,NULL,'laporan_warga','Laporan QR LP-20260828-0001 untuk tong BT-0501','{\"status_tong\": \"penuh\", \"trash_bin_id\": 20, \"public_report_id\": 21}','2026-08-28 06:34:52','2026-08-28 06:34:52'),(41,1,'trash_bin','Memperbarui tempat sampah Tong BTM Kampus B #1','[]','2026-08-28 09:44:03','2026-08-28 09:44:03'),(42,1,'trash_bin','Memperbarui tempat sampah Tong SMP Kampus B #2','[]','2026-08-28 09:45:16','2026-08-28 09:45:16'),(43,1,'trash_bin','Memperbarui tempat sampah Tong SMP Kampus B #3','[]','2026-08-28 09:45:34','2026-08-28 09:45:34'),(44,1,'trash_bin','Memperbarui tempat sampah Tong SMP Kampus B #3','[]','2026-08-28 09:45:59','2026-08-28 09:45:59'),(45,1,'trash_bin','Memperbarui tempat sampah Tong SMP Kampus B #4','[]','2026-08-28 09:46:19','2026-08-28 09:46:19'),(46,1,'trash_bin','Memperbarui tempat sampah Tong SMP Kampus B #5','[]','2026-08-28 09:46:53','2026-08-28 09:46:53'),(47,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #1','[]','2026-08-29 14:56:40','2026-08-29 14:56:40'),(48,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #1 menjadi kosong','[]','2026-08-29 14:56:49','2026-08-29 14:56:49'),(49,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #2','[]','2026-08-29 14:57:55','2026-08-29 14:57:55'),(50,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #2 menjadi kosong','[]','2026-08-29 14:58:03','2026-08-29 14:58:03'),(51,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #3','[]','2026-08-29 14:59:10','2026-08-29 14:59:10'),(52,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 2 Cileungsi #1','[]','2026-08-29 15:00:16','2026-08-29 15:00:16'),(53,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 2 Cileungsi #2 menjadi kosong','[]','2026-08-29 15:00:49','2026-08-29 15:00:49'),(54,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 2 Cileungsi #2','[]','2026-08-29 15:01:07','2026-08-29 15:01:07'),(55,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #1 menjadi kosong','[]','2026-08-29 15:02:17','2026-08-29 15:02:17'),(56,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #3','[]','2026-08-29 15:02:37','2026-08-29 15:02:37'),(57,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #4','[]','2026-08-29 15:03:39','2026-08-29 15:03:39'),(58,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #5','[]','2026-08-29 15:04:35','2026-08-29 15:04:35'),(59,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #2','[]','2026-08-29 15:05:36','2026-08-29 15:05:36'),(60,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #3','[]','2026-08-29 15:06:07','2026-08-29 15:06:07'),(61,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #2 menjadi kosong','[]','2026-08-29 15:06:24','2026-08-29 15:06:24'),(62,1,'trash_bin','Memperbarui tempat sampah Tong SMP Muhammadiyah 2 Cileungsi #1','[]','2026-08-29 15:07:34','2026-08-29 15:07:34'),(63,1,'trash_bin','Memperbarui tempat sampah Tong SMP Muhammadiyah 2 Cileungsi #2','[]','2026-08-29 15:08:23','2026-08-29 15:08:23'),(64,1,'trash_bin','Memperbarui tempat sampah Tong SD Muhammadiyah 2 Cileungsi #2','[]','2026-08-29 15:09:41','2026-08-29 15:09:41'),(65,1,'trash_bin','Memperbarui status tempat sampah Tong SD Muhammadiyah 2 Cileungsi #2 menjadi kosong','[]','2026-08-29 15:09:52','2026-08-29 15:09:52'),(66,1,'trash_bin','Memperbarui tempat sampah Tong SD Muhammadiyah 2 Cileungsi #3','[]','2026-08-29 15:10:29','2026-08-29 15:10:29'),(67,1,'trash_bin','Memperbarui tempat sampah Tong SD Muhammadiyah 3 Cileungsi #3','[]','2026-08-29 15:11:52','2026-08-29 15:11:52'),(68,1,'trash_bin','Memperbarui tempat sampah Tong SD Muhammadiyah 3 Cileungsi #1','[]','2026-08-29 15:12:25','2026-08-29 15:12:25'),(69,1,'trash_bin','Menghapus tempat sampah Tong BTM Kampus B #4','[]','2026-08-31 09:29:47','2026-08-31 09:29:47'),(70,1,'trash_bin','Menghapus tempat sampah Tong BTM Kampus B #5','[]','2026-08-31 09:29:53','2026-08-31 09:29:53'),(71,1,'trash_bin','Menghapus tempat sampah Tong BTM Kampus B #3','[]','2026-08-31 09:29:57','2026-08-31 09:29:57'),(72,1,'trash_bin','Menghapus tempat sampah Tong BTM Kampus B #2','[]','2026-08-31 09:30:00','2026-08-31 09:30:00'),(73,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #2','[]','2026-08-31 09:30:06','2026-08-31 09:30:06'),(74,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #3','[]','2026-08-31 09:30:09','2026-08-31 09:30:09'),(75,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #4','[]','2026-08-31 09:30:13','2026-08-31 09:30:13'),(76,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #5','[]','2026-08-31 09:30:16','2026-08-31 09:30:16'),(77,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #6','[]','2026-08-31 09:30:22','2026-08-31 09:30:22'),(78,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 2 Cileungsi #2','[]','2026-08-31 09:30:35','2026-08-31 09:30:35'),(79,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 2 Cileungsi #3','[]','2026-08-31 09:30:38','2026-08-31 09:30:38'),(80,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 2 Cileungsi #4','[]','2026-08-31 09:30:42','2026-08-31 09:30:42'),(81,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 3 Cileungsi #2','[]','2026-08-31 09:30:46','2026-08-31 09:30:46'),(82,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 3 Cileungsi #3','[]','2026-08-31 09:30:49','2026-08-31 09:30:49'),(83,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 3 Cileungsi #4','[]','2026-08-31 09:30:52','2026-08-31 09:30:52'),(84,1,'trash_bin','Menghapus tempat sampah Tong SMA Kampus B #2','[]','2026-08-31 09:31:07','2026-08-31 09:31:07'),(85,1,'trash_bin','Menghapus tempat sampah Tong SMA Kampus B #3','[]','2026-08-31 09:31:11','2026-08-31 09:31:11'),(86,1,'trash_bin','Menghapus tempat sampah Tong SMA Kampus B #4','[]','2026-08-31 09:31:16','2026-08-31 09:31:16'),(87,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #2','[]','2026-08-31 09:31:23','2026-08-31 09:31:23'),(88,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #3','[]','2026-08-31 09:31:27','2026-08-31 09:31:27'),(89,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #4','[]','2026-08-31 09:31:31','2026-08-31 09:31:31'),(90,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 2 Cileungsi #2','[]','2026-08-31 09:31:42','2026-08-31 09:31:42'),(91,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 2 Cileungsi #3','[]','2026-08-31 09:31:49','2026-08-31 09:31:49'),(92,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #2','[]','2026-08-31 09:31:57','2026-08-31 09:31:57'),(93,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #3','[]','2026-08-31 09:32:02','2026-08-31 09:32:02'),(94,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #4','[]','2026-08-31 09:32:07','2026-08-31 09:32:07'),(95,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #5','[]','2026-08-31 09:32:11','2026-08-31 09:32:11'),(96,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #2','[]','2026-08-31 09:32:19','2026-08-31 09:32:19'),(97,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #3','[]','2026-08-31 09:32:24','2026-08-31 09:32:24'),(98,1,'trash_bin','Menghapus tempat sampah Tong SMP Kampus B #2','[]','2026-08-31 09:32:31','2026-08-31 09:32:31'),(99,1,'trash_bin','Menghapus tempat sampah Tong SMP Kampus B #3','[]','2026-08-31 09:32:38','2026-08-31 09:32:38'),(100,1,'trash_bin','Menghapus tempat sampah Tong SMP Kampus B #4','[]','2026-08-31 09:32:44','2026-08-31 09:32:44'),(101,1,'trash_bin','Menghapus tempat sampah Tong SMP Kampus B #5','[]','2026-08-31 09:32:54','2026-08-31 09:32:54'),(102,1,'trash_bin','Menghapus tempat sampah Tong UMCI Kampus B #5','[]','2026-08-31 09:33:03','2026-08-31 09:33:03'),(103,1,'trash_bin','Menghapus tempat sampah Tong UMCI Kampus B #4','[]','2026-08-31 09:33:13','2026-08-31 09:33:13'),(104,1,'trash_bin','Menghapus tempat sampah Tong UMCI Kampus B #3','[]','2026-08-31 09:33:16','2026-08-31 09:33:16'),(105,1,'trash_bin','Menghapus tempat sampah Tong UMCI Kampus B #2','[]','2026-08-31 09:33:20','2026-08-31 09:33:20'),(106,1,'trash_bin','Menghapus tempat sampah Tong TK Kampus B #4','[]','2026-08-31 09:33:24','2026-08-31 09:33:24'),(107,1,'trash_bin','Menghapus tempat sampah Tong TK Kampus B #3','[]','2026-08-31 09:33:27','2026-08-31 09:33:27'),(108,1,'trash_bin','Menghapus tempat sampah Tong TK Kampus B #2','[]','2026-08-31 09:33:30','2026-08-31 09:33:30'),(109,1,'trash_bin','Menghapus tempat sampah Tong Sumart Kampus B #3','[]','2026-08-31 09:33:36','2026-08-31 09:33:36'),(110,1,'trash_bin','Menghapus tempat sampah Tong Sumart Kampus B #2','[]','2026-08-31 09:33:38','2026-08-31 09:33:38'),(111,1,'trash_bin','Menghapus tempat sampah Tong SMP Muhammadiyah 2 Cileungsi #3','[]','2026-08-31 09:33:43','2026-08-31 09:33:43'),(112,1,'trash_bin','Menghapus tempat sampah Tong SMP Muhammadiyah 2 Cileungsi #2','[]','2026-08-31 09:33:53','2026-08-31 09:33:53'),(113,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #1','[]','2026-08-31 09:36:17','2026-08-31 09:36:17'),(114,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 1 Cileungsi #1','[]','2026-08-31 09:37:08','2026-08-31 09:37:08'),(115,1,'trash_bin','Memperbarui tempat sampah Tong UMCI Kampus B #1','[]','2026-08-31 09:38:16','2026-08-31 09:38:16'),(116,1,'trash_bin','Menghapus tempat sampah Tong SMP Kampus B #1','[]','2026-08-31 09:39:35','2026-08-31 09:39:35'),(117,1,'trash_bin','Menghapus tempat sampah Tong TK Kampus B #1','[]','2026-08-31 09:39:41','2026-08-31 09:39:41'),(118,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 3 Cileungsi #1','[]','2026-08-31 09:39:45','2026-08-31 09:39:45'),(119,1,'trash_bin','Memperbarui tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #1','[]','2026-08-31 09:41:04','2026-08-31 09:41:04'),(120,1,'trash_bin','Memperbarui status tempat sampah Tong SMK Muhammadiyah 4 Cileungsi #1 menjadi penuh','[]','2026-08-31 09:41:12','2026-08-31 09:41:12'),(121,1,'trash_bin','Menghapus tempat sampah Tong Sumart Kampus B #1','[]','2026-08-31 09:42:56','2026-08-31 09:42:56'),(122,1,'trash_bin','Menghapus tempat sampah Tong SMK Muhammadiyah 3 Cileungsi #1','[]','2026-08-31 09:43:00','2026-08-31 09:43:00'),(123,1,'trash_bin','Menghapus tempat sampah Tong SMA Kampus B #1','[]','2026-08-31 09:43:06','2026-08-31 09:43:06'),(124,1,'trash_bin','Menghapus tempat sampah Tong SD Kampus B #1','[]','2026-08-31 09:44:24','2026-08-31 09:44:24'),(125,1,'trash_bin','Menghapus tempat sampah Tong SD Muhammadiyah 2 Cileungsi #1','[]','2026-08-31 09:44:27','2026-08-31 09:44:27'),(126,1,'trash_bin','Memperbarui tempat sampah Tong SMKM 1 #1','[]','2026-08-31 10:28:20','2026-08-31 10:28:20');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaints` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `trash_bin_id` bigint unsigned DEFAULT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('menunggu','diproses','selesai') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'menunggu',
  `tanggapan` text COLLATE utf8mb4_unicode_ci,
  `ditanggapi_oleh` bigint unsigned DEFAULT NULL,
  `ditanggapi_pada` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaints_user_id_foreign` (`user_id`),
  KEY `complaints_trash_bin_id_foreign` (`trash_bin_id`),
  KEY `complaints_ditanggapi_oleh_foreign` (`ditanggapi_oleh`),
  CONSTRAINT `complaints_ditanggapi_oleh_foreign` FOREIGN KEY (`ditanggapi_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE SET NULL,
  CONSTRAINT `complaints_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaints`
--

LOCK TABLES `complaints` WRITE;
/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gps_logs`
--

DROP TABLE IF EXISTS `gps_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gps_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trash_bin_id` bigint unsigned NOT NULL,
  `iot_device_id` bigint unsigned DEFAULT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `akurasi_meter` decimal(6,2) DEFAULT NULL COMMENT 'Estimasi akurasi GPS dalam meter (jika dikirim oleh perangkat).',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gps_logs_iot_device_id_foreign` (`iot_device_id`),
  KEY `gps_logs_trash_bin_id_created_at_index` (`trash_bin_id`,`created_at`),
  CONSTRAINT `gps_logs_iot_device_id_foreign` FOREIGN KEY (`iot_device_id`) REFERENCES `iot_devices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gps_logs_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gps_logs`
--

LOCK TABLES `gps_logs` WRITE;
/*!40000 ALTER TABLE `gps_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `gps_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iot_devices`
--

DROP TABLE IF EXISTS `iot_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iot_devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trash_bin_id` bigint unsigned NOT NULL,
  `device_token` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_token_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SHA-256 hash token perangkat untuk lookup autentikasi API.',
  `nama_perangkat` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nama perangkat IoT, misal: NodeMCU-T001.',
  `status_device` enum('online','offline') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'offline' COMMENT 'Online jika last_ping_at masih dalam threshold IOT_OFFLINE_THRESHOLD_MINUTES.',
  `last_ping_at` timestamp NULL DEFAULT NULL COMMENT 'Timestamp ping terakhir dari perangkat (POST /api/sensor/update).',
  `firmware_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Versi firmware Arduino/ESP8266 (opsional, untuk OTA tracking).',
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `iot_devices_trash_bin_id_unique` (`trash_bin_id`),
  UNIQUE KEY `iot_devices_device_token_unique` (`device_token`),
  UNIQUE KEY `iot_devices_device_token_hash_unique` (`device_token_hash`),
  KEY `iot_devices_status_device_index` (`status_device`),
  KEY `iot_devices_last_ping_at_index` (`last_ping_at`),
  CONSTRAINT `iot_devices_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iot_devices`
--

LOCK TABLES `iot_devices` WRITE;
/*!40000 ALTER TABLE `iot_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `iot_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_05_09_000001_create_roles_table',1),(5,'2026_05_09_000002_create_units_table',1),(6,'2026_05_09_000003_add_fields_to_users_table',1),(7,'2026_05_09_000004_create_trash_bins_table',1),(8,'2026_05_09_000005_create_trash_histories_table',1),(9,'2026_05_09_000006_create_complaints_table',1),(10,'2026_05_09_000007_create_reports_table',1),(11,'2026_05_09_000008_create_activities_table',1),(12,'2026_05_30_000001_add_geolocation_to_trash_bins_table',1),(13,'2026_06_15_100001_add_sensor_fields_to_trash_bins_table',1),(14,'2026_06_15_100002_create_iot_devices_table',1),(15,'2026_06_15_100003_create_sensor_logs_table',1),(16,'2026_06_15_100004_create_gps_logs_table',1),(17,'2026_06_15_100005_create_pickup_schedules_table',1),(18,'2026_06_15_100006_add_geolocation_to_trash_histories_table',1),(19,'2026_06_15_100007_create_public_reports_table',1),(20,'2026_06_15_100008_create_sipesa_notifications_table',1),(21,'2026_06_20_000001_add_confirmation_distance_to_trash_histories_table',1),(22,'2026_06_20_000002_add_device_token_hash_to_iot_devices_table',1),(23,'2026_06_20_000003_make_iot_device_tokens_hash_only',1),(24,'2026_08_27_000001_add_foto_to_public_reports_table',2),(25,'2026_08_29_000001_add_kampus_and_smk_to_units_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pickup_schedules`
--

DROP TABLE IF EXISTS `pickup_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pickup_schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trash_bin_id` bigint unsigned NOT NULL,
  `petugas_id` bigint unsigned DEFAULT NULL,
  `tanggal` date NOT NULL,
  `waktu_jadwal` time NOT NULL,
  `tipe` enum('rutin','darurat') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'rutin',
  `status` enum('terjadwal','selesai','terlambat','dibatalkan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'terjadwal',
  `public_report_id` bigint unsigned DEFAULT NULL COMMENT 'Jika jadwal darurat dibuat dari laporan warga.',
  `dibuat_oleh` bigint unsigned DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pickup_schedules_trash_bin_id_foreign` (`trash_bin_id`),
  KEY `pickup_schedules_dibuat_oleh_foreign` (`dibuat_oleh`),
  KEY `pickup_schedules_tanggal_status_index` (`tanggal`,`status`),
  KEY `pickup_schedules_petugas_id_tanggal_index` (`petugas_id`,`tanggal`),
  KEY `pickup_schedules_status_index` (`status`),
  KEY `pickup_schedules_public_report_id_foreign` (`public_report_id`),
  CONSTRAINT `pickup_schedules_dibuat_oleh_foreign` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pickup_schedules_petugas_id_foreign` FOREIGN KEY (`petugas_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pickup_schedules_public_report_id_foreign` FOREIGN KEY (`public_report_id`) REFERENCES `public_reports` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pickup_schedules_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pickup_schedules`
--

LOCK TABLES `pickup_schedules` WRITE;
/*!40000 ALTER TABLE `pickup_schedules` DISABLE KEYS */;
INSERT INTO `pickup_schedules` VALUES (4,20,6,'2026-08-27','13:00:00','rutin','terjadwal',NULL,1,'Jadwal rutin harian','2026-08-27 14:39:55','2026-08-27 14:39:55');
/*!40000 ALTER TABLE `pickup_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `public_reports`
--

DROP TABLE IF EXISTS `public_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `public_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nomor_tiket` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Format: LP-YYYYMMDD-XXXX. Counter XXXX direset per hari.',
  `trash_bin_id` bigint unsigned NOT NULL,
  `jenis_masalah` enum('penuh','rusak','bau','hama','pemilahan','lainnya') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pelapor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Opsional. Boleh dikosongkan untuk anonim sepenuhnya.',
  `deskripsi` text COLLATE utf8mb4_unicode_ci COMMENT 'Deskripsi tambahan, max 300 char (validasi di FormRequest).',
  `status` enum('menunggu','diproses','selesai','ditolak') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'menunggu',
  `catatan_admin` text COLLATE utf8mb4_unicode_ci COMMENT 'Catatan dari admin saat menindaklanjuti laporan.',
  `petugas_id` bigint unsigned DEFAULT NULL,
  `ditangani_oleh` bigint unsigned DEFAULT NULL,
  `ditangani_pada` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IPv4/IPv6 pelapor. Untuk duplicate detection & rate-limit.',
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_duplikat` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Tandai laporan duplikat (dari admin atau auto-merge).',
  `duplikat_dari_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `foto` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Bukti foto laporan (path di storage/public/laporan).',
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_reports_nomor_tiket_unique` (`nomor_tiket`),
  KEY `public_reports_petugas_id_foreign` (`petugas_id`),
  KEY `public_reports_ditangani_oleh_foreign` (`ditangani_oleh`),
  KEY `public_reports_duplikat_dari_id_foreign` (`duplikat_dari_id`),
  KEY `public_reports_status_created_at_index` (`status`,`created_at`),
  KEY `public_reports_trash_bin_id_jenis_masalah_created_at_index` (`trash_bin_id`,`jenis_masalah`,`created_at`),
  KEY `public_reports_ip_address_index` (`ip_address`),
  KEY `public_reports_jenis_masalah_index` (`jenis_masalah`),
  CONSTRAINT `public_reports_ditangani_oleh_foreign` FOREIGN KEY (`ditangani_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `public_reports_duplikat_dari_id_foreign` FOREIGN KEY (`duplikat_dari_id`) REFERENCES `public_reports` (`id`) ON DELETE SET NULL,
  CONSTRAINT `public_reports_petugas_id_foreign` FOREIGN KEY (`petugas_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `public_reports_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `public_reports`
--

LOCK TABLES `public_reports` WRITE;
/*!40000 ALTER TABLE `public_reports` DISABLE KEYS */;
INSERT INTO `public_reports` VALUES (17,'LP-20260827-0014',20,'bau','budi','Kondisi tong: Setengah penuh. bauu','menunggu',NULL,NULL,NULL,NULL,'172.22.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36',0,NULL,'2026-08-27 20:13:29','2026-08-27 20:13:29','laporan/ml3jqgQ9ulorW80hDpfWrghOU0AH0jaarc8oXPHU.jpg'),(21,'LP-20260828-0001',20,'penuh','Nafi','Kondisi tong: Penuh. Nd','menunggu',NULL,NULL,NULL,NULL,'172.22.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36',0,NULL,'2026-08-28 06:34:52','2026-08-28 06:34:52','laporan/IApCSnLcDlqumbG0zGDvT0dsrOv9mtoqKGNdLwjl.png');
/*!40000 ALTER TABLE `public_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi` text COLLATE utf8mb4_unicode_ci,
  `tipe` enum('harian','mingguan','bulanan') COLLATE utf8mb4_unicode_ci NOT NULL,
  `periode_mulai` date NOT NULL,
  `periode_selesai` date NOT NULL,
  `total_tong_penuh` int NOT NULL DEFAULT '0',
  `total_pengangkutan` int NOT NULL DEFAULT '0',
  `total_aduan` int NOT NULL DEFAULT '0',
  `ringkasan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_user_id_foreign` (`user_id`),
  KEY `reports_unit_id_foreign` (`unit_id`),
  CONSTRAINT `reports_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,1,1,'Rekap Harian SD Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-01','2026-08-01',2,3,1,'[demo-grafik-laporan]','2026-08-01 16:00:00','2026-08-01 16:20:00'),(2,1,2,'Rekap Mingguan SMP Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-26','2026-08-01',2,3,2,'[demo-grafik-laporan]','2026-08-01 16:01:00','2026-08-01 16:21:00'),(3,1,3,'Rekap Bulanan SMA Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-01',2,3,1,'[demo-grafik-laporan]','2026-08-01 16:02:00','2026-08-01 16:22:00'),(4,1,4,'Rekap Harian TK Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-01','2026-08-01',2,3,2,'[demo-grafik-laporan]','2026-08-01 16:03:00','2026-08-01 16:23:00'),(5,1,5,'Rekap Mingguan BTM Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-26','2026-08-01',2,3,1,'[demo-grafik-laporan]','2026-08-01 16:04:00','2026-08-01 16:24:00'),(6,1,6,'Rekap Bulanan Sumart Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-01',2,2,2,'[demo-grafik-laporan]','2026-08-01 16:05:00','2026-08-01 16:25:00'),(7,1,7,'Rekap Harian UMCI Kampus B 01 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-01','2026-08-01',2,3,1,'[demo-grafik-laporan]','2026-08-01 16:06:00','2026-08-01 16:26:00'),(8,1,1,'Rekap Mingguan SD Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-27','2026-08-02',2,3,2,'[demo-grafik-laporan]','2026-08-02 16:00:00','2026-08-02 16:20:00'),(9,1,2,'Rekap Bulanan SMP Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-02',2,3,1,'[demo-grafik-laporan]','2026-08-02 16:01:00','2026-08-02 16:21:00'),(10,1,3,'Rekap Harian SMA Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-02','2026-08-02',2,3,2,'[demo-grafik-laporan]','2026-08-02 16:02:00','2026-08-02 16:22:00'),(11,1,4,'Rekap Mingguan TK Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-27','2026-08-02',1,2,1,'[demo-grafik-laporan]','2026-08-02 16:03:00','2026-08-02 16:23:00'),(12,1,5,'Rekap Bulanan BTM Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-02',2,3,2,'[demo-grafik-laporan]','2026-08-02 16:04:00','2026-08-02 16:24:00'),(13,1,6,'Rekap Harian Sumart Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-02','2026-08-02',1,2,1,'[demo-grafik-laporan]','2026-08-02 16:05:00','2026-08-02 16:25:00'),(14,1,7,'Rekap Mingguan UMCI Kampus B 02 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-27','2026-08-02',2,3,2,'[demo-grafik-laporan]','2026-08-02 16:06:00','2026-08-02 16:26:00'),(15,1,1,'Rekap Bulanan SD Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-03',2,3,1,'[demo-grafik-laporan]','2026-08-03 16:00:00','2026-08-03 16:20:00'),(16,1,2,'Rekap Harian SMP Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-03','2026-08-03',2,3,2,'[demo-grafik-laporan]','2026-08-03 16:01:00','2026-08-03 16:21:00'),(17,1,3,'Rekap Mingguan SMA Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-28','2026-08-03',1,2,1,'[demo-grafik-laporan]','2026-08-03 16:02:00','2026-08-03 16:22:00'),(18,1,4,'Rekap Bulanan TK Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-03',2,3,2,'[demo-grafik-laporan]','2026-08-03 16:03:00','2026-08-03 16:23:00'),(19,1,5,'Rekap Harian BTM Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-03','2026-08-03',2,3,1,'[demo-grafik-laporan]','2026-08-03 16:04:00','2026-08-03 16:24:00'),(20,1,6,'Rekap Mingguan Sumart Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-28','2026-08-03',1,2,2,'[demo-grafik-laporan]','2026-08-03 16:05:00','2026-08-03 16:25:00'),(21,1,7,'Rekap Bulanan UMCI Kampus B 03 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-03',2,3,1,'[demo-grafik-laporan]','2026-08-03 16:06:00','2026-08-03 16:26:00'),(22,1,1,'Rekap Harian SD Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-04','2026-08-04',2,3,2,'[demo-grafik-laporan]','2026-08-04 16:00:00','2026-08-04 16:20:00'),(23,1,2,'Rekap Mingguan SMP Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-29','2026-08-04',2,3,1,'[demo-grafik-laporan]','2026-08-04 16:01:00','2026-08-04 16:21:00'),(24,1,3,'Rekap Bulanan SMA Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-04',2,3,2,'[demo-grafik-laporan]','2026-08-04 16:02:00','2026-08-04 16:22:00'),(25,1,4,'Rekap Harian TK Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-04','2026-08-04',2,3,1,'[demo-grafik-laporan]','2026-08-04 16:03:00','2026-08-04 16:23:00'),(26,1,5,'Rekap Mingguan BTM Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-29','2026-08-04',2,3,2,'[demo-grafik-laporan]','2026-08-04 16:04:00','2026-08-04 16:24:00'),(27,1,6,'Rekap Bulanan Sumart Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-04',2,2,1,'[demo-grafik-laporan]','2026-08-04 16:05:00','2026-08-04 16:25:00'),(28,1,7,'Rekap Harian UMCI Kampus B 04 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-04','2026-08-04',2,3,2,'[demo-grafik-laporan]','2026-08-04 16:06:00','2026-08-04 16:26:00'),(29,1,1,'Rekap Mingguan SD Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-30','2026-08-05',2,3,1,'[demo-grafik-laporan]','2026-08-05 16:00:00','2026-08-05 16:20:00'),(30,1,2,'Rekap Bulanan SMP Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-05',2,3,2,'[demo-grafik-laporan]','2026-08-05 16:01:00','2026-08-05 16:21:00'),(31,1,3,'Rekap Harian SMA Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-05','2026-08-05',2,3,1,'[demo-grafik-laporan]','2026-08-05 16:02:00','2026-08-05 16:22:00'),(32,1,4,'Rekap Mingguan TK Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-30','2026-08-05',1,2,2,'[demo-grafik-laporan]','2026-08-05 16:03:00','2026-08-05 16:23:00'),(33,1,5,'Rekap Bulanan BTM Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-05',2,3,1,'[demo-grafik-laporan]','2026-08-05 16:04:00','2026-08-05 16:24:00'),(34,1,6,'Rekap Harian Sumart Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-05','2026-08-05',1,2,2,'[demo-grafik-laporan]','2026-08-05 16:05:00','2026-08-05 16:25:00'),(35,1,7,'Rekap Mingguan UMCI Kampus B 05 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-30','2026-08-05',2,3,1,'[demo-grafik-laporan]','2026-08-05 16:06:00','2026-08-05 16:26:00'),(36,1,1,'Rekap Bulanan SD Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-06',2,3,2,'[demo-grafik-laporan]','2026-08-06 16:00:00','2026-08-06 16:20:00'),(37,1,2,'Rekap Harian SMP Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-06','2026-08-06',2,3,1,'[demo-grafik-laporan]','2026-08-06 16:01:00','2026-08-06 16:21:00'),(38,1,3,'Rekap Mingguan SMA Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-31','2026-08-06',1,2,2,'[demo-grafik-laporan]','2026-08-06 16:02:00','2026-08-06 16:22:00'),(39,1,4,'Rekap Bulanan TK Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-06',2,3,1,'[demo-grafik-laporan]','2026-08-06 16:03:00','2026-08-06 16:23:00'),(40,1,5,'Rekap Harian BTM Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-06','2026-08-06',2,3,2,'[demo-grafik-laporan]','2026-08-06 16:04:00','2026-08-06 16:24:00'),(41,1,6,'Rekap Mingguan Sumart Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-07-31','2026-08-06',1,2,1,'[demo-grafik-laporan]','2026-08-06 16:05:00','2026-08-06 16:25:00'),(42,1,7,'Rekap Bulanan UMCI Kampus B 06 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-06',2,3,2,'[demo-grafik-laporan]','2026-08-06 16:06:00','2026-08-06 16:26:00'),(43,1,1,'Rekap Harian SD Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-07','2026-08-07',2,3,1,'[demo-grafik-laporan]','2026-08-07 16:00:00','2026-08-07 16:20:00'),(44,1,2,'Rekap Mingguan SMP Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-01','2026-08-07',2,3,2,'[demo-grafik-laporan]','2026-08-07 16:01:00','2026-08-07 16:21:00'),(45,1,3,'Rekap Bulanan SMA Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-07',2,3,1,'[demo-grafik-laporan]','2026-08-07 16:02:00','2026-08-07 16:22:00'),(46,1,4,'Rekap Harian TK Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-07','2026-08-07',2,3,2,'[demo-grafik-laporan]','2026-08-07 16:03:00','2026-08-07 16:23:00'),(47,1,5,'Rekap Mingguan BTM Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-01','2026-08-07',2,3,1,'[demo-grafik-laporan]','2026-08-07 16:04:00','2026-08-07 16:24:00'),(48,1,6,'Rekap Bulanan Sumart Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-07',2,2,2,'[demo-grafik-laporan]','2026-08-07 16:05:00','2026-08-07 16:25:00'),(49,1,7,'Rekap Harian UMCI Kampus B 07 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-07','2026-08-07',2,3,1,'[demo-grafik-laporan]','2026-08-07 16:06:00','2026-08-07 16:26:00'),(50,1,1,'Rekap Mingguan SD Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-02','2026-08-08',2,3,2,'[demo-grafik-laporan]','2026-08-08 16:00:00','2026-08-08 16:20:00'),(51,1,2,'Rekap Bulanan SMP Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-08',2,3,1,'[demo-grafik-laporan]','2026-08-08 16:01:00','2026-08-08 16:21:00'),(52,1,3,'Rekap Harian SMA Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-08','2026-08-08',2,3,2,'[demo-grafik-laporan]','2026-08-08 16:02:00','2026-08-08 16:22:00'),(53,1,4,'Rekap Mingguan TK Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-02','2026-08-08',1,2,1,'[demo-grafik-laporan]','2026-08-08 16:03:00','2026-08-08 16:23:00'),(54,1,5,'Rekap Bulanan BTM Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-08',2,3,2,'[demo-grafik-laporan]','2026-08-08 16:04:00','2026-08-08 16:24:00'),(55,1,6,'Rekap Harian Sumart Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-08','2026-08-08',1,2,1,'[demo-grafik-laporan]','2026-08-08 16:05:00','2026-08-08 16:25:00'),(56,1,7,'Rekap Mingguan UMCI Kampus B 08 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-02','2026-08-08',2,3,2,'[demo-grafik-laporan]','2026-08-08 16:06:00','2026-08-08 16:26:00'),(57,1,1,'Rekap Bulanan SD Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-09',2,3,1,'[demo-grafik-laporan]','2026-08-09 16:00:00','2026-08-09 16:20:00'),(58,1,2,'Rekap Harian SMP Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-09','2026-08-09',2,3,2,'[demo-grafik-laporan]','2026-08-09 16:01:00','2026-08-09 16:21:00'),(59,1,3,'Rekap Mingguan SMA Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-03','2026-08-09',1,2,1,'[demo-grafik-laporan]','2026-08-09 16:02:00','2026-08-09 16:22:00'),(60,1,4,'Rekap Bulanan TK Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-09',2,3,2,'[demo-grafik-laporan]','2026-08-09 16:03:00','2026-08-09 16:23:00'),(61,1,5,'Rekap Harian BTM Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-09','2026-08-09',2,3,1,'[demo-grafik-laporan]','2026-08-09 16:04:00','2026-08-09 16:24:00'),(62,1,6,'Rekap Mingguan Sumart Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-03','2026-08-09',1,2,2,'[demo-grafik-laporan]','2026-08-09 16:05:00','2026-08-09 16:25:00'),(63,1,7,'Rekap Bulanan UMCI Kampus B 09 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-09',2,3,1,'[demo-grafik-laporan]','2026-08-09 16:06:00','2026-08-09 16:26:00'),(64,1,1,'Rekap Harian SD Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-10','2026-08-10',2,3,2,'[demo-grafik-laporan]','2026-08-10 16:00:00','2026-08-10 16:20:00'),(65,1,2,'Rekap Mingguan SMP Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-04','2026-08-10',2,3,1,'[demo-grafik-laporan]','2026-08-10 16:01:00','2026-08-10 16:21:00'),(66,1,3,'Rekap Bulanan SMA Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-10',2,3,2,'[demo-grafik-laporan]','2026-08-10 16:02:00','2026-08-10 16:22:00'),(67,1,4,'Rekap Harian TK Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-10','2026-08-10',2,3,1,'[demo-grafik-laporan]','2026-08-10 16:03:00','2026-08-10 16:23:00'),(68,1,5,'Rekap Mingguan BTM Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-04','2026-08-10',2,3,2,'[demo-grafik-laporan]','2026-08-10 16:04:00','2026-08-10 16:24:00'),(69,1,6,'Rekap Bulanan Sumart Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-10',2,2,1,'[demo-grafik-laporan]','2026-08-10 16:05:00','2026-08-10 16:25:00'),(70,1,7,'Rekap Harian UMCI Kampus B 10 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-10','2026-08-10',2,3,2,'[demo-grafik-laporan]','2026-08-10 16:06:00','2026-08-10 16:26:00'),(71,1,1,'Rekap Mingguan SD Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-05','2026-08-11',2,3,1,'[demo-grafik-laporan]','2026-08-11 16:00:00','2026-08-11 16:20:00'),(72,1,2,'Rekap Bulanan SMP Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-11',2,3,2,'[demo-grafik-laporan]','2026-08-11 16:01:00','2026-08-11 16:21:00'),(73,1,3,'Rekap Harian SMA Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-11','2026-08-11',2,3,1,'[demo-grafik-laporan]','2026-08-11 16:02:00','2026-08-11 16:22:00'),(74,1,4,'Rekap Mingguan TK Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-05','2026-08-11',1,2,2,'[demo-grafik-laporan]','2026-08-11 16:03:00','2026-08-11 16:23:00'),(75,1,5,'Rekap Bulanan BTM Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-11',2,3,1,'[demo-grafik-laporan]','2026-08-11 16:04:00','2026-08-11 16:24:00'),(76,1,6,'Rekap Harian Sumart Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-11','2026-08-11',1,2,2,'[demo-grafik-laporan]','2026-08-11 16:05:00','2026-08-11 16:25:00'),(77,1,7,'Rekap Mingguan UMCI Kampus B 11 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-05','2026-08-11',2,3,1,'[demo-grafik-laporan]','2026-08-11 16:06:00','2026-08-11 16:26:00'),(78,1,1,'Rekap Bulanan SD Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-12',2,3,2,'[demo-grafik-laporan]','2026-08-12 16:00:00','2026-08-12 16:20:00'),(79,1,2,'Rekap Harian SMP Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-12','2026-08-12',2,3,1,'[demo-grafik-laporan]','2026-08-12 16:01:00','2026-08-12 16:21:00'),(80,1,3,'Rekap Mingguan SMA Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-06','2026-08-12',1,2,2,'[demo-grafik-laporan]','2026-08-12 16:02:00','2026-08-12 16:22:00'),(81,1,4,'Rekap Bulanan TK Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-12',2,3,1,'[demo-grafik-laporan]','2026-08-12 16:03:00','2026-08-12 16:23:00'),(82,1,5,'Rekap Harian BTM Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-12','2026-08-12',2,3,2,'[demo-grafik-laporan]','2026-08-12 16:04:00','2026-08-12 16:24:00'),(83,1,6,'Rekap Mingguan Sumart Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-06','2026-08-12',1,2,1,'[demo-grafik-laporan]','2026-08-12 16:05:00','2026-08-12 16:25:00'),(84,1,7,'Rekap Bulanan UMCI Kampus B 12 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-12',2,3,2,'[demo-grafik-laporan]','2026-08-12 16:06:00','2026-08-12 16:26:00'),(85,1,1,'Rekap Harian SD Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-13','2026-08-13',2,3,1,'[demo-grafik-laporan]','2026-08-13 16:00:00','2026-08-13 16:20:00'),(86,1,2,'Rekap Mingguan SMP Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-07','2026-08-13',2,3,2,'[demo-grafik-laporan]','2026-08-13 16:01:00','2026-08-13 16:21:00'),(87,1,3,'Rekap Bulanan SMA Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-13',2,3,1,'[demo-grafik-laporan]','2026-08-13 16:02:00','2026-08-13 16:22:00'),(88,1,4,'Rekap Harian TK Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-13','2026-08-13',2,3,2,'[demo-grafik-laporan]','2026-08-13 16:03:00','2026-08-13 16:23:00'),(89,1,5,'Rekap Mingguan BTM Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-07','2026-08-13',2,3,1,'[demo-grafik-laporan]','2026-08-13 16:04:00','2026-08-13 16:24:00'),(90,1,6,'Rekap Bulanan Sumart Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-13',2,2,2,'[demo-grafik-laporan]','2026-08-13 16:05:00','2026-08-13 16:25:00'),(91,1,7,'Rekap Harian UMCI Kampus B 13 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-13','2026-08-13',2,3,1,'[demo-grafik-laporan]','2026-08-13 16:06:00','2026-08-13 16:26:00'),(92,1,1,'Rekap Mingguan SD Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-08','2026-08-14',2,3,2,'[demo-grafik-laporan]','2026-08-14 16:00:00','2026-08-14 16:20:00'),(93,1,2,'Rekap Bulanan SMP Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-14',2,3,1,'[demo-grafik-laporan]','2026-08-14 16:01:00','2026-08-14 16:21:00'),(94,1,3,'Rekap Harian SMA Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-14','2026-08-14',2,3,2,'[demo-grafik-laporan]','2026-08-14 16:02:00','2026-08-14 16:22:00'),(95,1,4,'Rekap Mingguan TK Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-08','2026-08-14',1,2,1,'[demo-grafik-laporan]','2026-08-14 16:03:00','2026-08-14 16:23:00'),(96,1,5,'Rekap Bulanan BTM Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-14',2,3,2,'[demo-grafik-laporan]','2026-08-14 16:04:00','2026-08-14 16:24:00'),(97,1,6,'Rekap Harian Sumart Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-14','2026-08-14',1,2,1,'[demo-grafik-laporan]','2026-08-14 16:05:00','2026-08-14 16:25:00'),(98,1,7,'Rekap Mingguan UMCI Kampus B 14 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-08','2026-08-14',2,3,2,'[demo-grafik-laporan]','2026-08-14 16:06:00','2026-08-14 16:26:00'),(99,1,1,'Rekap Bulanan SD Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-15',2,3,1,'[demo-grafik-laporan]','2026-08-15 16:00:00','2026-08-15 16:20:00'),(100,1,2,'Rekap Harian SMP Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-15','2026-08-15',2,3,2,'[demo-grafik-laporan]','2026-08-15 16:01:00','2026-08-15 16:21:00'),(101,1,3,'Rekap Mingguan SMA Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-09','2026-08-15',1,2,1,'[demo-grafik-laporan]','2026-08-15 16:02:00','2026-08-15 16:22:00'),(102,1,4,'Rekap Bulanan TK Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-15',2,3,2,'[demo-grafik-laporan]','2026-08-15 16:03:00','2026-08-15 16:23:00'),(103,1,5,'Rekap Harian BTM Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-15','2026-08-15',2,3,1,'[demo-grafik-laporan]','2026-08-15 16:04:00','2026-08-15 16:24:00'),(104,1,6,'Rekap Mingguan Sumart Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-09','2026-08-15',1,2,2,'[demo-grafik-laporan]','2026-08-15 16:05:00','2026-08-15 16:25:00'),(105,1,7,'Rekap Bulanan UMCI Kampus B 15 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-01','2026-08-15',2,3,1,'[demo-grafik-laporan]','2026-08-15 16:06:00','2026-08-15 16:26:00'),(106,1,1,'Rekap Harian SD Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-16','2026-08-16',2,3,2,'[demo-grafik-laporan]','2026-08-16 16:00:00','2026-08-16 16:20:00'),(107,1,2,'Rekap Mingguan SMP Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-10','2026-08-16',2,3,1,'[demo-grafik-laporan]','2026-08-16 16:01:00','2026-08-16 16:21:00'),(108,1,3,'Rekap Bulanan SMA Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-02','2026-08-16',2,3,2,'[demo-grafik-laporan]','2026-08-16 16:02:00','2026-08-16 16:22:00'),(109,1,4,'Rekap Harian TK Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-16','2026-08-16',2,3,1,'[demo-grafik-laporan]','2026-08-16 16:03:00','2026-08-16 16:23:00'),(110,1,5,'Rekap Mingguan BTM Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-10','2026-08-16',2,3,2,'[demo-grafik-laporan]','2026-08-16 16:04:00','2026-08-16 16:24:00'),(111,1,6,'Rekap Bulanan Sumart Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-02','2026-08-16',2,2,1,'[demo-grafik-laporan]','2026-08-16 16:05:00','2026-08-16 16:25:00'),(112,1,7,'Rekap Harian UMCI Kampus B 16 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-16','2026-08-16',2,3,2,'[demo-grafik-laporan]','2026-08-16 16:06:00','2026-08-16 16:26:00'),(113,1,1,'Rekap Mingguan SD Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-11','2026-08-17',2,3,1,'[demo-grafik-laporan]','2026-08-17 16:00:00','2026-08-17 16:20:00'),(114,1,2,'Rekap Bulanan SMP Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-03','2026-08-17',2,3,2,'[demo-grafik-laporan]','2026-08-17 16:01:00','2026-08-17 16:21:00'),(115,1,3,'Rekap Harian SMA Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-17','2026-08-17',2,3,1,'[demo-grafik-laporan]','2026-08-17 16:02:00','2026-08-17 16:22:00'),(116,1,4,'Rekap Mingguan TK Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-11','2026-08-17',1,2,2,'[demo-grafik-laporan]','2026-08-17 16:03:00','2026-08-17 16:23:00'),(117,1,5,'Rekap Bulanan BTM Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-03','2026-08-17',2,3,1,'[demo-grafik-laporan]','2026-08-17 16:04:00','2026-08-17 16:24:00'),(118,1,6,'Rekap Harian Sumart Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-17','2026-08-17',1,2,2,'[demo-grafik-laporan]','2026-08-17 16:05:00','2026-08-17 16:25:00'),(119,1,7,'Rekap Mingguan UMCI Kampus B 17 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-11','2026-08-17',2,3,1,'[demo-grafik-laporan]','2026-08-17 16:06:00','2026-08-17 16:26:00'),(120,1,1,'Rekap Bulanan SD Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-04','2026-08-18',2,3,2,'[demo-grafik-laporan]','2026-08-18 16:00:00','2026-08-18 16:20:00'),(121,1,2,'Rekap Harian SMP Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-18','2026-08-18',2,3,1,'[demo-grafik-laporan]','2026-08-18 16:01:00','2026-08-18 16:21:00'),(122,1,3,'Rekap Mingguan SMA Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-12','2026-08-18',1,2,2,'[demo-grafik-laporan]','2026-08-18 16:02:00','2026-08-18 16:22:00'),(123,1,4,'Rekap Bulanan TK Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-04','2026-08-18',2,3,1,'[demo-grafik-laporan]','2026-08-18 16:03:00','2026-08-18 16:23:00'),(124,1,5,'Rekap Harian BTM Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-18','2026-08-18',2,3,2,'[demo-grafik-laporan]','2026-08-18 16:04:00','2026-08-18 16:24:00'),(125,1,6,'Rekap Mingguan Sumart Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-12','2026-08-18',1,2,1,'[demo-grafik-laporan]','2026-08-18 16:05:00','2026-08-18 16:25:00'),(126,1,7,'Rekap Bulanan UMCI Kampus B 18 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-04','2026-08-18',2,3,2,'[demo-grafik-laporan]','2026-08-18 16:06:00','2026-08-18 16:26:00'),(127,1,1,'Rekap Harian SD Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-19','2026-08-19',2,3,1,'[demo-grafik-laporan]','2026-08-19 16:00:00','2026-08-19 16:20:00'),(128,1,2,'Rekap Mingguan SMP Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-13','2026-08-19',2,3,2,'[demo-grafik-laporan]','2026-08-19 16:01:00','2026-08-19 16:21:00'),(129,1,3,'Rekap Bulanan SMA Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-05','2026-08-19',2,3,1,'[demo-grafik-laporan]','2026-08-19 16:02:00','2026-08-19 16:22:00'),(130,1,4,'Rekap Harian TK Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-19','2026-08-19',2,3,2,'[demo-grafik-laporan]','2026-08-19 16:03:00','2026-08-19 16:23:00'),(131,1,5,'Rekap Mingguan BTM Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-13','2026-08-19',2,3,1,'[demo-grafik-laporan]','2026-08-19 16:04:00','2026-08-19 16:24:00'),(132,1,6,'Rekap Bulanan Sumart Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-05','2026-08-19',2,2,2,'[demo-grafik-laporan]','2026-08-19 16:05:00','2026-08-19 16:25:00'),(133,1,7,'Rekap Harian UMCI Kampus B 19 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-19','2026-08-19',2,3,1,'[demo-grafik-laporan]','2026-08-19 16:06:00','2026-08-19 16:26:00'),(134,1,1,'Rekap Mingguan SD Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-14','2026-08-20',2,3,2,'[demo-grafik-laporan]','2026-08-20 16:00:00','2026-08-20 16:20:00'),(135,1,2,'Rekap Bulanan SMP Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-06','2026-08-20',2,3,1,'[demo-grafik-laporan]','2026-08-20 16:01:00','2026-08-20 16:21:00'),(136,1,3,'Rekap Harian SMA Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-20','2026-08-20',2,3,2,'[demo-grafik-laporan]','2026-08-20 16:02:00','2026-08-20 16:22:00'),(137,1,4,'Rekap Mingguan TK Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-14','2026-08-20',1,2,1,'[demo-grafik-laporan]','2026-08-20 16:03:00','2026-08-20 16:23:00'),(138,1,5,'Rekap Bulanan BTM Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-06','2026-08-20',2,3,2,'[demo-grafik-laporan]','2026-08-20 16:04:00','2026-08-20 16:24:00'),(139,1,6,'Rekap Harian Sumart Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-20','2026-08-20',1,2,1,'[demo-grafik-laporan]','2026-08-20 16:05:00','2026-08-20 16:25:00'),(140,1,7,'Rekap Mingguan UMCI Kampus B 20 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-14','2026-08-20',2,3,2,'[demo-grafik-laporan]','2026-08-20 16:06:00','2026-08-20 16:26:00'),(141,1,1,'Rekap Bulanan SD Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-07','2026-08-21',2,3,1,'[demo-grafik-laporan]','2026-08-21 16:00:00','2026-08-21 16:20:00'),(142,1,2,'Rekap Harian SMP Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-21','2026-08-21',2,3,2,'[demo-grafik-laporan]','2026-08-21 16:01:00','2026-08-21 16:21:00'),(143,1,3,'Rekap Mingguan SMA Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-15','2026-08-21',1,2,1,'[demo-grafik-laporan]','2026-08-21 16:02:00','2026-08-21 16:22:00'),(144,1,4,'Rekap Bulanan TK Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-07','2026-08-21',2,3,2,'[demo-grafik-laporan]','2026-08-21 16:03:00','2026-08-21 16:23:00'),(145,1,5,'Rekap Harian BTM Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-21','2026-08-21',2,3,1,'[demo-grafik-laporan]','2026-08-21 16:04:00','2026-08-21 16:24:00'),(146,1,6,'Rekap Mingguan Sumart Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-15','2026-08-21',1,2,2,'[demo-grafik-laporan]','2026-08-21 16:05:00','2026-08-21 16:25:00'),(147,1,7,'Rekap Bulanan UMCI Kampus B 21 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-07','2026-08-21',2,3,1,'[demo-grafik-laporan]','2026-08-21 16:06:00','2026-08-21 16:26:00'),(148,1,1,'Rekap Harian SD Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-22','2026-08-22',2,3,2,'[demo-grafik-laporan]','2026-08-22 16:00:00','2026-08-22 16:20:00'),(149,1,2,'Rekap Mingguan SMP Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-16','2026-08-22',2,3,1,'[demo-grafik-laporan]','2026-08-22 16:01:00','2026-08-22 16:21:00'),(150,1,3,'Rekap Bulanan SMA Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-08','2026-08-22',2,3,2,'[demo-grafik-laporan]','2026-08-22 16:02:00','2026-08-22 16:22:00'),(151,1,4,'Rekap Harian TK Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-22','2026-08-22',2,3,1,'[demo-grafik-laporan]','2026-08-22 16:03:00','2026-08-22 16:23:00'),(152,1,5,'Rekap Mingguan BTM Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-16','2026-08-22',2,3,2,'[demo-grafik-laporan]','2026-08-22 16:04:00','2026-08-22 16:24:00'),(153,1,6,'Rekap Bulanan Sumart Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-08','2026-08-22',2,2,1,'[demo-grafik-laporan]','2026-08-22 16:05:00','2026-08-22 16:25:00'),(154,1,7,'Rekap Harian UMCI Kampus B 22 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-22','2026-08-22',2,3,2,'[demo-grafik-laporan]','2026-08-22 16:06:00','2026-08-22 16:26:00'),(155,1,1,'Rekap Mingguan SD Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-17','2026-08-23',2,3,1,'[demo-grafik-laporan]','2026-08-23 16:00:00','2026-08-23 16:20:00'),(156,1,2,'Rekap Bulanan SMP Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-09','2026-08-23',2,3,2,'[demo-grafik-laporan]','2026-08-23 16:01:00','2026-08-23 16:21:00'),(157,1,3,'Rekap Harian SMA Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-23','2026-08-23',2,3,1,'[demo-grafik-laporan]','2026-08-23 16:02:00','2026-08-23 16:22:00'),(158,1,4,'Rekap Mingguan TK Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-17','2026-08-23',1,2,2,'[demo-grafik-laporan]','2026-08-23 16:03:00','2026-08-23 16:23:00'),(159,1,5,'Rekap Bulanan BTM Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-09','2026-08-23',2,3,1,'[demo-grafik-laporan]','2026-08-23 16:04:00','2026-08-23 16:24:00'),(160,1,6,'Rekap Harian Sumart Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-23','2026-08-23',1,2,2,'[demo-grafik-laporan]','2026-08-23 16:05:00','2026-08-23 16:25:00'),(161,1,7,'Rekap Mingguan UMCI Kampus B 23 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-17','2026-08-23',2,3,1,'[demo-grafik-laporan]','2026-08-23 16:06:00','2026-08-23 16:26:00'),(162,1,1,'Rekap Bulanan SD Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-10','2026-08-24',2,3,2,'[demo-grafik-laporan]','2026-08-24 16:00:00','2026-08-24 16:20:00'),(163,1,2,'Rekap Harian SMP Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-24','2026-08-24',2,3,1,'[demo-grafik-laporan]','2026-08-24 16:01:00','2026-08-24 16:21:00'),(164,1,3,'Rekap Mingguan SMA Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-18','2026-08-24',1,2,2,'[demo-grafik-laporan]','2026-08-24 16:02:00','2026-08-24 16:22:00'),(165,1,4,'Rekap Bulanan TK Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-10','2026-08-24',2,3,1,'[demo-grafik-laporan]','2026-08-24 16:03:00','2026-08-24 16:23:00'),(166,1,5,'Rekap Harian BTM Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-24','2026-08-24',2,3,2,'[demo-grafik-laporan]','2026-08-24 16:04:00','2026-08-24 16:24:00'),(167,1,6,'Rekap Mingguan Sumart Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-18','2026-08-24',1,2,1,'[demo-grafik-laporan]','2026-08-24 16:05:00','2026-08-24 16:25:00'),(168,1,7,'Rekap Bulanan UMCI Kampus B 24 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-10','2026-08-24',2,3,2,'[demo-grafik-laporan]','2026-08-24 16:06:00','2026-08-24 16:26:00'),(169,1,1,'Rekap Harian SD Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-25','2026-08-25',2,3,1,'[demo-grafik-laporan]','2026-08-25 16:00:00','2026-08-25 16:20:00'),(170,1,2,'Rekap Mingguan SMP Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-19','2026-08-25',2,3,2,'[demo-grafik-laporan]','2026-08-25 16:01:00','2026-08-25 16:21:00'),(171,1,3,'Rekap Bulanan SMA Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-11','2026-08-25',2,3,1,'[demo-grafik-laporan]','2026-08-25 16:02:00','2026-08-25 16:22:00'),(172,1,4,'Rekap Harian TK Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-25','2026-08-25',2,3,2,'[demo-grafik-laporan]','2026-08-25 16:03:00','2026-08-25 16:23:00'),(173,1,5,'Rekap Mingguan BTM Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-19','2026-08-25',2,3,1,'[demo-grafik-laporan]','2026-08-25 16:04:00','2026-08-25 16:24:00'),(174,1,6,'Rekap Bulanan Sumart Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-11','2026-08-25',2,2,2,'[demo-grafik-laporan]','2026-08-25 16:05:00','2026-08-25 16:25:00'),(175,1,7,'Rekap Harian UMCI Kampus B 25 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-25','2026-08-25',2,3,1,'[demo-grafik-laporan]','2026-08-25 16:06:00','2026-08-25 16:26:00'),(176,1,1,'Rekap Mingguan SD Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-20','2026-08-26',2,3,2,'[demo-grafik-laporan]','2026-08-26 16:00:00','2026-08-26 16:20:00'),(177,1,2,'Rekap Bulanan SMP Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-12','2026-08-26',2,3,1,'[demo-grafik-laporan]','2026-08-26 16:01:00','2026-08-26 16:21:00'),(178,1,3,'Rekap Harian SMA Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-26','2026-08-26',2,3,2,'[demo-grafik-laporan]','2026-08-26 16:02:00','2026-08-26 16:22:00'),(179,1,4,'Rekap Mingguan TK Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-20','2026-08-26',1,2,1,'[demo-grafik-laporan]','2026-08-26 16:03:00','2026-08-26 16:23:00'),(180,1,5,'Rekap Bulanan BTM Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-12','2026-08-26',2,3,2,'[demo-grafik-laporan]','2026-08-26 16:04:00','2026-08-26 16:24:00'),(181,1,6,'Rekap Harian Sumart Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-26','2026-08-26',1,2,1,'[demo-grafik-laporan]','2026-08-26 16:05:00','2026-08-26 16:25:00'),(182,1,7,'Rekap Mingguan UMCI Kampus B 26 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-20','2026-08-26',2,3,2,'[demo-grafik-laporan]','2026-08-26 16:06:00','2026-08-26 16:26:00'),(183,1,1,'Rekap Bulanan SD Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-13','2026-08-27',2,3,1,'[demo-grafik-laporan]','2026-08-27 16:00:00','2026-08-27 16:20:00'),(184,1,2,'Rekap Harian SMP Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-27','2026-08-27',2,3,2,'[demo-grafik-laporan]','2026-08-27 16:01:00','2026-08-27 16:21:00'),(185,1,3,'Rekap Mingguan SMA Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-21','2026-08-27',1,2,1,'[demo-grafik-laporan]','2026-08-27 16:02:00','2026-08-27 16:22:00'),(186,1,4,'Rekap Bulanan TK Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-13','2026-08-27',2,3,2,'[demo-grafik-laporan]','2026-08-27 16:03:00','2026-08-27 16:23:00'),(187,1,5,'Rekap Harian BTM Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','harian','2026-08-27','2026-08-27',2,3,1,'[demo-grafik-laporan]','2026-08-27 16:04:00','2026-08-27 16:24:00'),(188,1,6,'Rekap Mingguan Sumart Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','mingguan','2026-08-21','2026-08-27',1,2,2,'[demo-grafik-laporan]','2026-08-27 16:05:00','2026-08-27 16:25:00'),(189,1,7,'Rekap Bulanan UMCI Kampus B 27 Aug 2026','Rekap otomatis untuk menampilkan grafik laporan bulan berjalan di semua unit.','bulanan','2026-08-13','2026-08-27',2,3,1,'[demo-grafik-laporan]','2026-08-27 16:06:00','2026-08-27 16:26:00');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','Super Admin','Akses penuh ke seluruh sistem (CRUD semua unit).','2026-08-27 14:39:51','2026-08-27 14:39:51'),(2,'admin_unit','Admin Unit','Mengelola unit masing-masing (CRUD dalam unit).','2026-08-27 14:39:51','2026-08-27 14:39:51'),(3,'kepala_unit','Kepala Unit','Hanya melihat data unitnya sendiri (read-only, scope unit).','2026-08-27 14:39:51','2026-08-27 14:39:51'),(4,'kepala_pusat','Kepala Pusat','Melihat seluruh data sistem semua unit (read-only).','2026-08-27 14:39:51','2026-08-27 14:39:51'),(5,'petugas','Petugas','Petugas pengangkut sampah lapangan.','2026-08-27 14:39:51','2026-08-27 14:39:51'),(6,'siswa','Siswa','Siswa/civitas yang dapat membuat aduan internal.','2026-08-27 14:39:51','2026-08-27 14:39:51');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor_logs`
--

DROP TABLE IF EXISTS `sensor_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `iot_device_id` bigint unsigned NOT NULL,
  `trash_bin_id` bigint unsigned NOT NULL,
  `jarak_cm` decimal(6,2) NOT NULL COMMENT 'Jarak terukur dari sensor HC-SR04 ke permukaan sampah (cm).',
  `persentase_kepenuhan` decimal(5,2) NOT NULL COMMENT 'Persentase kepenuhan saat log dicatat (0-100).',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sensor_logs_iot_device_id_foreign` (`iot_device_id`),
  KEY `sensor_logs_trash_bin_id_created_at_index` (`trash_bin_id`,`created_at`),
  KEY `sensor_logs_created_at_index` (`created_at`),
  CONSTRAINT `sensor_logs_iot_device_id_foreign` FOREIGN KEY (`iot_device_id`) REFERENCES `iot_devices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sensor_logs_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_logs`
--

LOCK TABLES `sensor_logs` WRITE;
/*!40000 ALTER TABLE `sensor_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sipesa_notifications`
--

DROP TABLE IF EXISTS `sipesa_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sipesa_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` enum('penuh','terlambat','offline','laporan_baru','jadwal_baru','lainnya') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lainnya',
  `trash_bin_id` bigint unsigned DEFAULT NULL,
  `public_report_id` bigint unsigned DEFAULT NULL,
  `pickup_schedule_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `action_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL tujuan saat notifikasi diklik (opsional).',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sipesa_notifications_trash_bin_id_foreign` (`trash_bin_id`),
  KEY `sipesa_notifications_public_report_id_foreign` (`public_report_id`),
  KEY `sipesa_notifications_pickup_schedule_id_foreign` (`pickup_schedule_id`),
  KEY `sipesa_notifications_user_id_is_read_created_at_index` (`user_id`,`is_read`,`created_at`),
  KEY `sipesa_notifications_tipe_created_at_index` (`tipe`,`created_at`),
  CONSTRAINT `sipesa_notifications_pickup_schedule_id_foreign` FOREIGN KEY (`pickup_schedule_id`) REFERENCES `pickup_schedules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sipesa_notifications_public_report_id_foreign` FOREIGN KEY (`public_report_id`) REFERENCES `public_reports` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sipesa_notifications_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sipesa_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sipesa_notifications`
--

LOCK TABLES `sipesa_notifications` WRITE;
/*!40000 ALTER TABLE `sipesa_notifications` DISABLE KEYS */;
INSERT INTO `sipesa_notifications` VALUES (1,'Laporan warga baru','Tong BT-0501 dilaporkan setengah penuh melalui QR.','laporan_baru',20,NULL,NULL,NULL,0,NULL,'https://127.0.0.1:8443/admin/trash-bins?search=BT-0501','2026-08-27 16:12:36','2026-08-27 16:12:36'),(2,'Laporan warga baru','Tong BT-0501 dilaporkan penuh melalui QR.','laporan_baru',20,NULL,NULL,NULL,0,NULL,'https://127.0.0.1:8443/admin/trash-bins?search=BT-0501','2026-08-27 16:23:36','2026-08-27 16:23:36'),(3,'Laporan warga baru','Tong BT-0501 dilaporkan penuh melalui QR.','laporan_baru',20,NULL,NULL,NULL,0,NULL,'https://127.0.0.1:8443/admin/trash-bins?search=BT-0501','2026-08-27 16:47:35','2026-08-27 16:47:35'),(4,'Laporan warga baru','Tong BT-0501 dilaporkan setengah penuh melalui QR.','laporan_baru',20,NULL,NULL,NULL,0,NULL,'https://127.0.0.1:8443/admin/trash-bins?search=BT-0501','2026-08-27 17:00:44','2026-08-27 17:00:44'),(5,'Laporan warga baru','Tong SD-0103 dilaporkan setengah penuh melalui QR.','laporan_baru',NULL,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=SD-0103','2026-08-27 17:03:26','2026-08-27 17:03:26'),(6,'Laporan warga baru','Tong BT-0501 dilaporkan penuh melalui QR.','laporan_baru',20,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0501','2026-08-27 19:09:53','2026-08-27 19:09:53'),(7,'Laporan warga baru','Tong SD-0103 dilaporkan penuh melalui QR.','laporan_baru',NULL,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=SD-0103','2026-08-27 19:57:11','2026-08-27 19:57:11'),(8,'Laporan warga baru','Tong BT-0501 dilaporkan setengah penuh melalui QR.','laporan_baru',20,17,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0501','2026-08-27 20:13:29','2026-08-27 20:13:29'),(9,'Laporan warga baru','Tong BT-0502 dilaporkan setengah penuh melalui QR.','laporan_baru',NULL,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0502','2026-08-27 20:14:02','2026-08-27 20:14:02'),(10,'Laporan warga baru','Tong BT-0503 dilaporkan penuh melalui QR.','laporan_baru',NULL,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0503','2026-08-27 20:14:08','2026-08-27 20:14:08'),(11,'Laporan warga baru','Tong BT-0504 dilaporkan penuh melalui QR.','laporan_baru',NULL,NULL,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0504','2026-08-27 20:14:48','2026-08-27 20:14:48'),(12,'Laporan warga baru','Tong BT-0501 dilaporkan penuh melalui QR.','laporan_baru',20,21,NULL,NULL,0,NULL,'https://cherome.my.id/admin/trash-bins?search=BT-0501','2026-08-28 06:34:52','2026-08-28 06:34:52');
/*!40000 ALTER TABLE `sipesa_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trash_bins`
--

DROP TABLE IF EXISTS `trash_bins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trash_bins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_sampah` enum('organik','anorganik') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tinggi_tong_cm` decimal(6,2) DEFAULT NULL COMMENT 'Tinggi total tong dalam cm. Dipakai menghitung persentase kepenuhan dari sensor ultrasonik.',
  `persentase_kepenuhan` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Persentase kepenuhan terkini (0-100). Diupdate otomatis dari data sensor IoT.',
  `last_sensor_at` timestamp NULL DEFAULT NULL COMMENT 'Timestamp data sensor terakhir diterima. Untuk deteksi perangkat offline.',
  `status` enum('kosong','setengah_penuh','penuh','sudah_diangkut') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'kosong',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `terakhir_diangkut` timestamp NULL DEFAULT NULL,
  `terakhir_diangkut_oleh` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trash_bins_kode_unique` (`kode`),
  KEY `trash_bins_unit_id_foreign` (`unit_id`),
  KEY `trash_bins_terakhir_diangkut_oleh_foreign` (`terakhir_diangkut_oleh`),
  CONSTRAINT `trash_bins_terakhir_diangkut_oleh_foreign` FOREIGN KEY (`terakhir_diangkut_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trash_bins_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trash_bins`
--

LOCK TABLES `trash_bins` WRITE;
/*!40000 ALTER TABLE `trash_bins` DISABLE KEYS */;
INSERT INTO `trash_bins` VALUES (20,'BT-0501','Tong BTM Kampus B #1',5,'BTM Kampus B - Area A','anorganik',65.00,23.00,'2026-08-27 14:11:54','penuh','Tong sampah otomatis terdata',NULL,-6.3991398,106.9659576,NULL,NULL,'2026-08-27 14:39:54','2026-08-28 09:44:03'),(28,'UM-0701','Tong UMCI Kampus B #1',7,'UMCI Kampus B - Area A','anorganik',93.00,77.00,NULL,'penuh','Tong sampah otomatis terdata',NULL,-6.3933565,106.9796762,NULL,NULL,'2026-08-27 14:39:54','2026-08-31 09:38:16'),(33,'SM-0801','Tong SMKM 1 #1',8,'SMKM 1 - Area A','anorganik',64.00,99.00,NULL,'kosong','Tong sampah otomatis terdata',NULL,-6.4054402,106.9647310,NULL,NULL,'2026-08-29 14:04:10','2026-08-31 10:28:20'),(46,'SM-1101','Tong SMPM 2 #1',11,'SMPM 2 - Area A','organik',102.00,66.00,NULL,'setengah_penuh','Tong sampah otomatis terdata',NULL,-6.3670804,106.9888212,NULL,NULL,'2026-08-29 14:04:10','2026-08-29 15:07:34'),(49,'SM-1201','Tong SMKM 2 #1',12,'SMKM 2 - Area A','anorganik',118.00,30.00,NULL,'kosong','Tong sampah otomatis terdata',NULL,-6.4309924,106.9629776,NULL,NULL,'2026-08-29 14:04:10','2026-08-29 15:00:16'),(56,'SM-1401','Tong SMKM 4 #1',14,'SMKM 4 - Area A','anorganik',102.00,0.00,NULL,'penuh','Tong sampah otomatis terdata',NULL,-6.4121355,106.9586588,NULL,NULL,'2026-08-29 14:04:10','2026-08-31 09:41:12');
/*!40000 ALTER TABLE `trash_bins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trash_histories`
--

DROP TABLE IF EXISTS `trash_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trash_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `trash_bin_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `pickup_schedule_id` bigint unsigned DEFAULT NULL,
  `status_sebelum` enum('kosong','setengah_penuh','penuh','sudah_diangkut') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_sesudah` enum('kosong','setengah_penuh','penuh','sudah_diangkut') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` datetime NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude_konfirmasi` decimal(10,7) DEFAULT NULL,
  `longitude_konfirmasi` decimal(10,7) DEFAULT NULL,
  `jarak_konfirmasi_meter` decimal(8,2) DEFAULT NULL COMMENT 'Jarak petugas ke titik tong saat konfirmasi pengangkutan.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trash_histories_trash_bin_id_foreign` (`trash_bin_id`),
  KEY `trash_histories_user_id_foreign` (`user_id`),
  KEY `trash_histories_pickup_schedule_id_foreign` (`pickup_schedule_id`),
  CONSTRAINT `trash_histories_pickup_schedule_id_foreign` FOREIGN KEY (`pickup_schedule_id`) REFERENCES `pickup_schedules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trash_histories_trash_bin_id_foreign` FOREIGN KEY (`trash_bin_id`) REFERENCES `trash_bins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `trash_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=541 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trash_histories`
--

LOCK TABLES `trash_histories` WRITE;
/*!40000 ALTER TABLE `trash_histories` DISABLE KEYS */;
INSERT INTO `trash_histories` VALUES (18,28,6,NULL,'penuh','kosong','2026-08-01 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(32,20,7,NULL,'penuh','kosong','2026-08-02 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(51,20,6,NULL,'penuh','kosong','2026-08-03 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(56,28,6,NULL,'penuh','kosong','2026-08-03 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(76,28,7,NULL,'penuh','kosong','2026-08-04 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(90,20,6,NULL,'penuh','kosong','2026-08-05 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:55','2026-08-27 14:39:55'),(109,20,7,NULL,'penuh','kosong','2026-08-06 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(114,28,7,NULL,'penuh','kosong','2026-08-06 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(134,28,6,NULL,'penuh','kosong','2026-08-07 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(148,20,7,NULL,'penuh','kosong','2026-08-08 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(167,20,6,NULL,'penuh','kosong','2026-08-09 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(172,28,6,NULL,'penuh','kosong','2026-08-09 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(192,28,7,NULL,'penuh','kosong','2026-08-10 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(206,20,6,NULL,'penuh','kosong','2026-08-11 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:56','2026-08-27 14:39:56'),(225,20,7,NULL,'penuh','kosong','2026-08-12 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(230,28,7,NULL,'penuh','kosong','2026-08-12 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(250,28,6,NULL,'penuh','kosong','2026-08-13 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(264,20,7,NULL,'penuh','kosong','2026-08-14 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(283,20,6,NULL,'penuh','kosong','2026-08-15 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(288,28,6,NULL,'penuh','kosong','2026-08-15 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(308,28,7,NULL,'penuh','kosong','2026-08-16 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(322,20,6,NULL,'penuh','kosong','2026-08-17 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(341,20,7,NULL,'penuh','kosong','2026-08-18 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(346,28,7,NULL,'penuh','kosong','2026-08-18 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(366,28,6,NULL,'penuh','kosong','2026-08-19 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(380,20,7,NULL,'penuh','kosong','2026-08-20 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:57','2026-08-27 14:39:57'),(399,20,6,NULL,'penuh','kosong','2026-08-21 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(404,28,6,NULL,'penuh','kosong','2026-08-21 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(424,28,7,NULL,'penuh','kosong','2026-08-22 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(438,20,6,NULL,'penuh','kosong','2026-08-23 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(457,20,7,NULL,'penuh','kosong','2026-08-24 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(462,28,7,NULL,'penuh','kosong','2026-08-24 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(482,28,6,NULL,'penuh','kosong','2026-08-25 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(496,20,7,NULL,'penuh','kosong','2026-08-26 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(515,20,6,NULL,'penuh','kosong','2026-08-27 11:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58'),(520,28,6,NULL,'penuh','kosong','2026-08-27 13:15:00','[demo-grafik-laporan] Pengangkutan rutin bulan ini',NULL,NULL,NULL,NULL,'2026-08-27 14:39:58','2026-08-27 14:39:58');
/*!40000 ALTER TABLE `trash_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kampus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis` enum('SD','SMP','SMA','SMK','TK','BTM','Sumart','Umci','Lainnya') COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `no_telepon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'SD Kampus B','Kampus B','SD','Jl. Pendidikan No. 1, Kampus B',NULL,'Sekolah Dasar','2026-08-27 14:39:51','2026-08-27 14:39:51'),(2,'SMP Kampus B','Kampus B','SMP','Jl. Pendidikan No. 2, Kampus B',NULL,'Sekolah Menengah Pertama','2026-08-27 14:39:51','2026-08-27 14:39:51'),(3,'SMA Kampus B','Kampus B','SMA','Jl. Pendidikan No. 3, Kampus B',NULL,'Sekolah Menengah Atas','2026-08-27 14:39:51','2026-08-27 14:39:51'),(4,'TK Kampus B','Kampus B','TK','Jl. Pendidikan No. 4, Kampus B',NULL,'Taman Kanak-Kanak','2026-08-27 14:39:51','2026-08-27 14:39:51'),(5,'BTM Kampus B','Kampus B','BTM','Jl. Pendidikan No. 5, Kampus B',NULL,'Balai Teknologi dan Manajemen','2026-08-27 14:39:51','2026-08-27 14:39:51'),(6,'Sumart Kampus B','Kampus B','Sumart','Jl. Pendidikan No. 6, Kampus B',NULL,'Mini Market / Kantin','2026-08-27 14:39:51','2026-08-27 14:39:51'),(7,'UMCI Kampus B','Kampus B','Umci','Jl. Pendidikan No. 7, Kampus B',NULL,'Unit MCI','2026-08-27 14:39:51','2026-08-27 14:39:51'),(8,'SMKM 1','Kampus A','SMK','Kampus A, Cileungsi, Bogor',NULL,'SMK Muhammadiyah 1 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(9,'SMKM 3','Kampus A','SMK','Kampus A, Cileungsi, Bogor',NULL,'SMK Muhammadiyah 3 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(10,'SDM 2','Kampus C','SD','Kampus C, Cileungsi, Bogor',NULL,'SD Muhammadiyah 2 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(11,'SMPM 2','Kampus C','SMP','Kampus C, Cileungsi, Bogor',NULL,'SMP Muhammadiyah 2 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(12,'SMKM 2','Kampus D','SMK','Kampus D, Cileungsi, Bogor',NULL,'SMK Muhammadiyah 2 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(13,'SDM 3','Kampus D','SD','Kampus D, Cileungsi, Bogor',NULL,'SD Muhammadiyah 3 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10'),(14,'SMKM 4','Kampus E','SMK','Kampus E, Cileungsi, Bogor',NULL,'SMK Muhammadiyah 4 Cileungsi','2026-08-29 14:04:10','2026-08-29 14:04:10');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` bigint unsigned DEFAULT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telepon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  KEY `users_unit_id_foreign` (`unit_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super Admin','superadmin@sipesa.test',1,NULL,'2026-08-27 14:39:51','$2y$12$BXOQXICsF2fContWAExLbOeDxKUAYd2IS18ecstRm2qJqT33UbvVq','081200000001',NULL,NULL,NULL,'2026-08-27 14:39:51','2026-08-27 14:39:51'),(2,'Admin SD','adminsd@sipesa.test',2,1,'2026-08-27 14:39:52','$2y$12$MnMdQe5BDx01eB2Zrxvu3OhJb9xHYFinRo0YP8cy9xvZwFBbFtIvu','081200000002',NULL,NULL,NULL,'2026-08-27 14:39:52','2026-08-27 14:39:52'),(3,'Kepala Unit SD','kepala.sd@sipesa.test',3,1,'2026-08-27 14:39:52','$2y$12$X275wiNDDUoe1IlemXzlHeiR9X0X5eUEhjAZ0ebtA2Ikeb5JTA8XO','081200000010',NULL,NULL,NULL,'2026-08-27 14:39:52','2026-08-27 14:39:52'),(4,'Kepala Unit SMP','kepala.smp@sipesa.test',3,2,'2026-08-27 14:39:52','$2y$12$e088g3xIhC9/1.7/QI71G.We/97dfAiNx.szfRuOpeFeCLzUMTj.C','081200000011',NULL,NULL,NULL,'2026-08-27 14:39:52','2026-08-27 14:39:52'),(5,'Kepala Pusat','kepala.pusat@sipesa.test',4,NULL,'2026-08-27 14:39:53','$2y$12$.ilWBOSC.Q.WRjS.21upyuM7Fhob7dNnvXwSd4wtPYzDSACqokXm6','081200000020',NULL,NULL,NULL,'2026-08-27 14:39:53','2026-08-27 14:39:53'),(6,'Petugas 1','petugas@sipesa.test',5,1,'2026-08-27 14:39:53','$2y$12$CU7hZxP9/hkh23LbrUpcduUqvmePgx7VdwWGISrJDW73/KmNdhv0O','081200000003','dayeuh\ndayeuh',NULL,'7NAEtUJXhEja6JF7sahzB2wSNwb5POKYYaA1aE9zOH8FSjVYt7i7A1waFypv','2026-08-27 14:39:53','2026-08-27 20:44:34'),(7,'Petugas 2','petugas2@sipesa.test',5,2,'2026-08-27 14:39:53','$2y$12$Zam/Pfal7tmbXMNp0JPkn.w5mUPNazSMkbcPmWsPed/tzRsUaxXzK','081200000004',NULL,NULL,NULL,'2026-08-27 14:39:53','2026-08-27 14:39:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-31 10:19:31
